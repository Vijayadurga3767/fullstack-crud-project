from django.apps import AppConfig


class AskingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'asking'
